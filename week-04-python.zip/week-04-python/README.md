# Проверка на заимствования — Python

Запуск примера:      `python main.py`
Запуск тестов:       `python -m unittest discover -s tests -t .`  (или `pytest`)

- `model.py` — домен: Assignment, SubmittedWork, Student, GradeBook, CheckResult; не знает о поставщиках.
- `checks/` — адаптеры TextGuard и CodeMatch (`checkFunc` со схемы).
- `vendors/` — имитации SDK поставщиков (сторонний код, не менять).
